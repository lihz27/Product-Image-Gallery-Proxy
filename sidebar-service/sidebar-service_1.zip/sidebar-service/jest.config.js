module.exports = {
    globalSetup: './client/src/spec/setup.js',
    globalTeardown: './client/src/spec/teardown.js',
    testEnvironment: './client/src/spec/mongo-environment.js',
    testURL: 'http://localhost/',
    verbose: true
  };